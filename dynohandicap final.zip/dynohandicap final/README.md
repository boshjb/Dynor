# DynoHandicap

Système prédictif adaptatif pour courses hippiques.
